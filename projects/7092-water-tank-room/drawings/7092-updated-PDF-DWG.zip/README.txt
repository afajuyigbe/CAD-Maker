7092 HOWMIC COURT
Complete four-sheet PDF and AutoCAD2000 DWG.
Extract all files to the same folder. Keep 7092-floor-plan-background.png beside the DWG to display the original floor-plan underlay.
DWG drawing sheets use A3 sheet-space millimetres; four named layouts.
