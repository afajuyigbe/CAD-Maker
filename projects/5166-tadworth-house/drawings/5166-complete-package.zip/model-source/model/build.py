"""5166 review geometry. mm; X east, Y north, Z above GA ground datum.
GA plan topology graphically fitted to engineer survey references. Unmeasured
facade bays/finish details are visual interpretations, not fabrication geometry.
"""
from pathlib import Path
import json,math
import numpy as np
P=Path(__file__).resolve().parents[1];O=P/'model';D=P/'drawings'
XGA=[326.2,372,411.9,417.1,506,582,619.8,729.5];XM=[0,2400,4500,4750,9550,13050,14750,20250]
# Lower northeast terrace outline is visible on the GA outside the upper roof.
# Its unmeasured extent is graphically fitted; roof/support coordinates remain fixed.
TERRACE_EAST_GA=767.4
TERRACE_EAST_X=XM[-1]+(TERRACE_EAST_GA-XGA[-1])*(XM[-1]-XM[-2])/(XGA[-1]-XGA[-2])
XGA=XGA+[TERRACE_EAST_GA];XM=XM+[TERRACE_EAST_X]
YGA=[252.9,311.1,397.,548.8,584.4];YM=[16961.,13961.,9322.4,1922.4,0.]
def xy(x,y):return np.array([np.interp(x,XGA,XM),np.interp(y,YGA,YM)])
V=[];F=[];G=[];M=[]
C={'brick':(.58,.39,.28),'band':(.87,.86,.80),'roof':(.76,.75,.69),'glass':(.27,.39,.44),'frame':(.88,.90,.88),'steel':(.62,.68,.70),'equipment':(.88,.88,.84),'dark':(.22,.25,.25),'walkway':(.31,.36,.32),'mortar':(.57,.40,.30),'vent':(.84,.70,.19)}
def face(pts,g,m):
 a=np.array(pts,float)
 if np.linalg.norm(np.cross(a[1]-a[0],a[2]-a[0]))<1e-7:return
 ix=[]
 for p in a:V.append(p.tolist());ix.append(len(V))
 F.append(ix);G.append(g);M.append(m)
def box(x,y,z,l,w,h,g,m='steel'):
 q=[(x,y,z),(x+l,y,z),(x+l,y+w,z),(x,y+w,z),(x,y,z+h),(x+l,y,z+h),(x+l,y+w,z+h),(x,y+w,z+h)]
 for ix in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:face([q[i] for i in ix],g,m)
def beam(a,b,width,depth,g,m='steel'):
 a=np.array(a,float);b=np.array(b,float);u=b-a;u=u/np.linalg.norm(u);v=np.cross(u,[0,0,1])
 if np.linalg.norm(v)<.01:v=np.array([1.,0,0])
 v=v/np.linalg.norm(v)*width/2;w=np.cross(u,v);w=w/np.linalg.norm(w)*depth/2
 pts=[a-v-w,a+v-w,a+v+w,a-v+w,b-v-w,b+v-w,b+v+w,b-v+w]
 for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:face([pts[i] for i in ids],g,m)
def tube(a,b,r,g,m='steel',n=10):
 a=np.array(a,float);b=np.array(b,float);u=b-a;u/=np.linalg.norm(u);v=np.cross(u,[0,0,1])
 if np.linalg.norm(v)<.1:v=np.array([1.,0,0])
 v/=np.linalg.norm(v);w=np.cross(u,v);q=[a+r*(v*math.cos(i*2*math.pi/n)+w*math.sin(i*2*math.pi/n)) for i in range(n)];t=[p+b-a for p in q]
 face(q[::-1],g,m);face(t,g,m)
 for i in range(n):face([q[i],q[(i+1)%n],t[(i+1)%n],t[i]],g,m)
outlineGA=[(326.2,397),(411.9,397),(411.9,252.9),(619.8,252.9),(619.8,311.1),(729.5,311.1),(729.5,584.4),(582,584.4),(582,548.8),(326.2,548.8)]
outline=[xy(*p) for p in outlineGA];roof=26100
# Roof broken into rectangular panels, avoiding diagonal display lines.
for xa,xb,ya,yb in [(326.2,411.9,397,548.8),(411.9,582,252.9,548.8),(582,619.8,252.9,584.4),(619.8,729.5,311.1,584.4)]:
 a=xy(xa,yb);b=xy(xb,ya);face([(a[0],a[1],roof),(b[0],a[1],roof),(b[0],b[1],roof),(a[0],b[1],roof)],'existing_roof','roof')
# Each facade follows the exact stepped GA edge topology. Bays are photo interpretations.
for k,(a,b) in enumerate(zip(outline,outline[1:]+outline[:1])):
 u=b-a;length=np.linalg.norm(u);u=u/length;out=np.array([-u[1],u[0]])
 # Outline is clockwise in world axes: outward is left of edge.
 def quad(s0,s1,z0,z1,offset,g,m):
  aa=a+u*s0+out*offset;bb=a+u*s1+out*offset
  face([(aa[0],aa[1],z0),(bb[0],bb[1],z0),(bb[0],bb[1],z1),(aa[0],aa[1],z1)],g,m)
 long=length>6500;bay=(length*.58,length*.87) if long else None
 if bay:
  lo,hi=bay;quad(0,lo,0,roof,0,f'facade_{k}','brick');quad(hi,length,0,roof,0,f'facade_{k}','brick');quad(lo,hi,0,roof,-1400,f'balcony_recess_{k}','dark')
  for end in [lo,hi]:
   aa=a+u*end;bb=aa-out*1400;face([(aa[0],aa[1],0),(bb[0],bb[1],0),(bb[0],bb[1],roof),(aa[0],aa[1],roof)],f'balcony_return_{k}','brick')
  # Continuous visible supports retain their full vertical extent.
  for s in [lo,hi]:
   q=a+u*s;beam((*q,0),(*q,roof),220,220,f'facade_column_{k}','band')
  for z in [4000+3100*i for i in range(7)]:
   aa=a+u*lo;bb=a+u*hi;aa=aa+out*220;bb=bb+out*220;rr=-out*1620
   face([(*aa,z),(*bb,z),(*(bb+rr),z),(*(aa+rr),z)],f'balcony_slab_{k}','band')
   quad(lo,hi,z-160,z,220,f'balcony_edge_{k}','band');quad(lo,hi,z,z+850,230,f'balcony_parapet_{k}','brick')
   beam((*(a+u*lo+out*250),z+1000),(*(a+u*hi+out*250),z+1000),45,45,f'balcony_rail_{k}','steel')
   quad(lo+200,hi-200,z+950,z+2600,-1380,f'balcony_door_{k}','glass')
   quad((lo+hi)/2-30,(lo+hi)/2+30,z+950,z+2600,-1360,f'balcony_door_frame_{k}','frame')
  spans=[(0,lo),(hi,length)]
 else:quad(0,length,0,roof,0,f'facade_{k}','brick');spans=[(0,length)]
 # White floor bands and photo-led paired windows, never treated as structural grid.
 for z in [3650+3100*i for i in range(8)]:
  if z>roof:continue
  for lo,hi in spans:quad(lo,hi,z,z+180,20,f'floor_band_{k}','band')
 for lo,hi in spans:
  span=hi-lo
  count=max(1,int(span/3600));centres=np.linspace(lo+span/(count*2),hi-span/(count*2),count)
  for z in [4900+3100*i for i in range(7)]:
   if z+1450>roof-300:continue
   for s in centres:
    ww=min(1800,span/count*.63)
    quad(s-ww/2-60,s+ww/2+60,z-60,z+1460,35,f'window_frame_{k}','frame');quad(s-ww/2,s+ww/2,z,z+1400,45,f'window_glass_{k}','glass');quad(s-25,s+25,z,z+1400,50,f'window_mullion_{k}','frame')
  # Ground-storey glazing, separate from upper residential windows.
  count=max(1,int(span/1800))
  for j in range(count):
   s0=lo+(j+.08)*span/count;s1=lo+(j+.92)*span/count
   quad(s0,s1,500,2700,35,f'ground_glazing_{k}','glass')
  # Restrained horizontal brick joints; material rather than invented structural members.
  for z in np.arange(4200,roof,450):quad(lo,hi,z,z+12,7,f'cosmetic_mortar_{k}','mortar')
 # Solid parapet at roof edge, source height780.
 quad(0,length,roof,roof+780,0,f'parapet_{k}','brick');beam((*a,roof+780),(*b,roof+780),180,70,f'parapet_coping_{k}','band')
# Vertical stair glazing bay, matched to photographs at stepped return.
xa,ya=xy(411.9,350);box(xa-25,ya-1200,500,55,2350,25000,'stair_glazing','glass')
for z in np.arange(3200,25500,3100):box(xa-80,ya-1220,z,120,2390,180,'stair_transoms','frame')
for yy in [ya-1200,ya,ya+1200]:box(xa-85,yy-45,0,140,90,26100,'stair_vertical_frames','frame')
# Replace only the upper storey with a clearer photo/survey-based representation.
# Floor level and member envelopes below are visual section proxies, not surveyed sizes.
TOP_BASE=23000.;ROOF_SOFFIT=25850.
old=[(np.array([V[i-1] for i in f]),g,m) for f,g,m in zip(F,G,M)]
V=[];F=[];G=[];M=[]
def clip_z(poly,z,above):
 out=[]
 for a,b in zip(poly,np.roll(poly,-1,axis=0)):
  ina=a[2]>=z-1e-8 if above else a[2]<=z+1e-8;inb=b[2]>=z-1e-8 if above else b[2]<=z+1e-8
  if ina:out.append(a)
  if ina!=inb:out.append(a+(b-a)*(z-a[2])/(b[2]-a[2]))
 return out
for poly,g,m in old:
 if g.startswith(('facade_','balcony_','window_','ground_','floor_','stair_','cosmetic_')):poly=clip_z(poly,TOP_BASE,False)
 if len(poly)>=3:face(poly,g,m)
C['concrete']=(.79,.80,.77);C['bearing_wall']=(.69,.48,.34)
# Full floor and roof-soffit panels; open balcony zones lie between room walls and roof edge.
for xa,xb,ya,yb in [(326.2,411.9,397,548.8),(411.9,582,252.9,548.8),(582,619.8,252.9,584.4),(619.8,729.5,311.1,584.4)]:
 a=xy(xa,yb);b=xy(xb,ya)
 face([(a[0],a[1],TOP_BASE),(b[0],a[1],TOP_BASE),(b[0],b[1],TOP_BASE),(a[0],b[1],TOP_BASE)],'topfloor_floor','concrete')
 face([(a[0],a[1],ROOF_SOFFIT),(a[0],b[1],ROOF_SOFFIT),(b[0],b[1],ROOF_SOFFIT),(b[0],a[1],ROOF_SOFFIT)],'roof_slab_soffit','concrete')
for a,b in zip(outline,outline[1:]+outline[:1]):
 face([(*a,ROOF_SOFFIT),(*b,ROOF_SOFFIT),(*b,roof),(*a,roof)],'roof_slab_edge','concrete')
# Recessed enclosing wall line: the overhangs are open, not full-height facade panels.
bodyGA=[(372,397),(411.9,397),(411.9,252.9),(582,252.9),(582,311.1),(698,311.1),(698,397),(729.5,397),(729.5,548.8),(372,548.8)]
body=[xy(*q) for q in bodyGA]
for k,(a,b) in enumerate(zip(body,body[1:]+body[:1])):
 u=b-a;L=float(np.linalg.norm(u));u=u/L;out=np.array([-u[1],u[0]])
 def panel(s0,s1,z0,z1,offset,g,m):
  aa=a+u*s0+out*offset;bb=a+u*s1+out*offset
  face([(*aa,z0),(*bb,z0),(*bb,z1),(*aa,z1)],g,m)
 balcony_edge=k in [3,5,8,9]
 if L<1000:
  panel(0,L,TOP_BASE,ROOF_SOFFIT,0,'topfloor_exterior_'+str(k),'brick');continue
 n=max(1,int(L/3400));spacing=L/n;ww=min(1900,spacing*.68);zlo=TOP_BASE+(180 if balcony_edge else 850);zhi=TOP_BASE+(2200 if balcony_edge else 2200)
 cursor=0.
 for j in range(n):
  centre=(j+.5)*spacing;lo=centre-ww/2;hi=centre+ww/2
  if lo>cursor:panel(cursor,lo,TOP_BASE,ROOF_SOFFIT,0,'topfloor_exterior_'+str(k),'brick')
  if zlo>TOP_BASE:panel(lo,hi,TOP_BASE,zlo,0,'topfloor_exterior_'+str(k),'brick')
  panel(lo,hi,zhi,ROOF_SOFFIT,0,'topfloor_exterior_'+str(k),'brick')
  panel(lo,hi,zlo,zhi,-20,'topfloor_window_'+str(k),'glass')
  for ss in [lo,hi,centre]:panel(ss-35,ss+35,zlo,zhi,25,'topfloor_window_frame_'+str(k),'frame')
  panel(lo,hi,zlo-35,zlo+35,25,'topfloor_window_frame_'+str(k),'frame');panel(lo,hi,zhi-35,zhi+35,25,'topfloor_window_frame_'+str(k),'frame')
  cursor=hi
 if cursor<L:panel(cursor,L,TOP_BASE,ROOF_SOFFIT,0,'topfloor_exterior_'+str(k),'brick')
 panel(0,L,ROOF_SOFFIT-180,ROOF_SOFFIT,15,'topfloor_head_band_'+str(k),'band')
# Internal bearing walls are surface representations on engineer-marked wall lines.
wallGA=[((506,252.9),(506,548.8)),((582,311.1),(582,548.8)),((411.9,397),(698,397)),((506,374),(582,374))]
for k,(aa,bb) in enumerate(wallGA):
 a=xy(*aa);b=xy(*bb);face([(*a,TOP_BASE),(*b,TOP_BASE),(*b,ROOF_SOFFIT),(*a,ROOF_SOFFIT)],'topfloor_bearing_wall_'+str(k),'bearing_wall')
# Balcony floor edges and low brick fronts, separated from roof soffit and outer columns.
balconyGA=[((326.2,397),(326.2,548.8)),((326.2,548.8),(372,548.8)),((582,548.8),(582,584.4)),((582,584.4),(729.5,584.4)),((729.5,548.8),(729.5,584.4)),((582,252.9),(767.4,252.9)),((767.4,252.9),(767.4,397)),((767.4,397),(729.5,397))]
for k,(aa,bb) in enumerate(balconyGA):
 a=xy(*aa);b=xy(*bb)
 face([(*a,TOP_BASE-180),(*b,TOP_BASE-180),(*b,TOP_BASE),(*a,TOP_BASE)],'topfloor_balcony_slab_edge_'+str(k),'band')
 face([(*a,TOP_BASE),(*b,TOP_BASE),(*b,TOP_BASE+800),(*a,TOP_BASE+800)],'topfloor_balcony_front_'+str(k),'brick')
 beam((*a,TOP_BASE+800),(*b,TOP_BASE+800),100,80,'topfloor_balcony_coping_'+str(k),'band')
 tube((*a,TOP_BASE+1000),(*b,TOP_BASE+1000),25,'topfloor_balcony_rail_'+str(k),'steel')
# Extend the eighth-floor terrace through the northeast roof notch and beyond the east roof edge.
# This is the lower balcony/floor footprint, not an enlargement of the upper roof.
for xa,xb,ya,yb in [(619.8,729.5,252.9,311.1),(729.5,767.4,252.9,397)]:
 a=xy(xa,yb);b=xy(xb,ya)
 face([(a[0],a[1],TOP_BASE),(b[0],a[1],TOP_BASE),(b[0],b[1],TOP_BASE),(a[0],b[1],TOP_BASE)],'northeast_eighth_floor_terrace','concrete')
# Columns and overhang beams follow the latest engineer-marked positions/paths.
columnGA=[(506,252.9),(582,252.9),(729.5,345.2),(506,548.8),(582,548.8),(729.5,548.8),(372,548.8)]
for k,pt in enumerate(columnGA):
 q=xy(*pt);box(q[0]-110,q[1]-110,TOP_BASE,220,220,ROOF_SOFFIT-TOP_BASE,'topfloor_photo_column_'+str(k),'band')
beamGA=[((506,252.9),(619.8,252.9)),((619.8,252.9),(619.8,311.1)),((698,311.1),(729.5,311.1)),((729.5,311.1),(729.5,397)),((326.2,397),(372,397)),((326.2,397),(326.2,548.8)),((326.2,548.8),(372,548.8)),((582,548.8),(582,584.4)),((582,584.4),(729.5,584.4)),((729.5,548.8),(729.5,584.4))]
for k,(aa,bb) in enumerate(beamGA):
 a=xy(*aa);b=xy(*bb);beam((*a,ROOF_SOFFIT-150),(*b,ROOF_SOFFIT-150),220,300,'topfloor_overhang_beam_'+str(k),'band')
# Central plant room and photographed skylight, footprint from GA.
def ga_box(x0,y0,x1,y1,z,h,g,m):
 a=xy(x0,y1);b=xy(x1,y0);box(*a,z,b[0]-a[0],b[1]-a[1],h,g,m)
ga_box(507,289,584,411,roof,1320,'roof_plant_room','band');ga_box(507,289,584,411,27420,80,'plant_room_roof','dark')
ga_box(527,418,563,447,roof,300,'skylight_frame','steel');ga_box(530,421,560,444,roof+310,80,'skylight_glass','glass')
for x,y,r in [(590,477,335),(454,330,100),(468,545,60),(686,490,60),(614,385,57),(493,467,100)]:
 a=xy(x,y);tube((*a,roof),(*a,roof+450),r,'existing_roof_vents','vent')
# Roof support geometry. Steel footprints follow GA; separate location references below.
# Central cabinet platform: source grillage setting-out3960x3790.
a=xy(518,528);gx,gy=a;gw,gd=3960,3790;deck=roof+650
for xx in [gx,gx+gw-150]:box(xx,gy,roof+350,150,gd,150,'cabinet_grillage_PFC','steel')
for yy in [gy,gy+gd-150]:box(gx,yy,roof+350,gw,150,150,'cabinet_grillage_PFC','steel')
for xx in [gx+80,gx+gw-80]:
 for yy in [gy+80,gy+gd-80]:box(xx-125,yy-125,roof,250,250,350,'cabinet_grillage_plinth','steel')
face([(gx,gy,deck),(gx+gw,gy,deck),(gx+gw,gy+gd,deck),(gx,gy+gd,deck)],'cabinet_platform_mesh','steel')
for xx in np.arange(gx,gx+gw,220):beam((xx,gy,deck+5),(xx,gy+gd,deck+5),12,12,'platform_mesh_lines','dark')
for xx in [gx,gx+gw]:
 for yy in np.linspace(gy,gy+gd,4):beam((xx,yy,deck),(xx,yy,deck+1100),45,45,'platform_handrail')
 beam((xx,gy,deck+1100),(xx,gy+gd,deck+1100),45,45,'platform_handrail')
for yy in [gy,gy+gd]:beam((gx,yy,deck+1100),(gx+gw,yy,deck+1100),45,45,'platform_handrail')
for i,(w,d,h) in enumerate([(1200,600,1600),(650,700,1100),(650,700,1100)]):box(gx+350+i*1000,gy+900,deck,w,d,h,'proposed_cabinet_'+str(i),'equipment')
# Three sectors: equipment all uses common source sizes and azimuths; beams/feet are individually grouped.
sectors=[('S1',0,xy(600,270),4300,2700),('S2',100,xy(716,532),3900,2600),('S3',230,xy(386,535),5500,3900)]
sector_record=[]
for name,az,c,L1,L2 in sectors:
 # L-shaped supporting beams, oriented locally to fit corner. Overall sizes fromA7 memberdetails.
 if name=='S1':u=np.array([-1.,0]);v=np.array([0.,-1.])
 elif name=='S2':u=np.array([-1.,0]);v=np.array([0.,1.])
 else:u=np.array([1.,0]);v=np.array([0.,1.])
 p0=c-u*450;p1=p0+u*L1;p2=p0+v*L2;z=roof+350
 for a,b in [(p0,p1),(p0,p2)]:beam((*a,z),(*b,z),203,203,name+'_support_beams')
 for a in [p0,p1,p2]:box(a[0]-150,a[1]-150,roof,300,300,250,name+'_steel_plinth')
 # Source Valmont: one vertical mast at the base corner, braced back to two feet.
 mast=p0.copy();feet=[mast,mast+u*2100,mast+v*2100]
 tube((*mast,z+100),(*mast,roof+5100),70,name+'_braced_mast')
 for foot in feet[1:]:tube((*foot,z+100),(*mast,roof+1800),38,name+'_mast_braces')
 for foot in feet[1:]:beam((*mast,z+80),(*foot,z+80),65,65,name+'_mast_base')
 bearing=math.radians(az);fwd=np.array([math.sin(bearing),math.cos(bearing)]);right=np.array([fwd[1],-fwd[0]])
 left=mast-right*850+fwd*230;right_carrier=mast+right*850+fwd*230
 tube((*left,28650),(*left,31300),38,name+'_left_carrier')
 tube((*right_carrier,28650),(*right_carrier,31450),38,name+'_right_carrier')
 for zz in [28950,30750]:
  beam((*left,zz),(*right_carrier,zz),65,125,name+'_yoke_brackets')
  beam((*mast,zz),(*(mast+fwd*230),zz),65,65,name+'_yoke_standoff')
 for j,(w,dep,h) in enumerate([(498,197,1500),(400,200,650),(500,250,2300)]):
  cpanel=(right_carrier if j in [0,1] else left)+fwd*150;cz=[29575,31050,30000][j]
  # Exact orientation: rectangular panel faces towards GA azimuth.
  pp=[]
  for zz in [cz-h/2,cz+h/2]:
   for rr,ff in [(-w/2,-dep/2),(w/2,-dep/2),(w/2,dep/2),(-w/2,dep/2)]:pp.append((*(cpanel+right*rr+fwd*ff),zz))
  for ix in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:face([pp[k] for k in ix],name+'_antenna_'+str(j),'equipment')
 for j,(rw,rd,rh) in enumerate([(342,160,420),(342,160,420),(398,190,553),(398,151,553),(495,404,163)]):
  r=mast+right*((j%3)-1)*500-fwd*380;box(r[0]-rw/2,r[1]-rd/2,roof+1100+(j//3)*650,rw,rd,rh,name+'_radio_'+str(j),'equipment')
 sector_record.append({'id':name,'azimuth':az,'GA_anchor':c.tolist(),'plinths':[q.tolist() for q in [p0,p1,p2]],'support_beam_lengths':[L1,L2],'mast':mast.tolist(),'antenna_arrangement':'one H3G panel on left carrier; two EE panels stacked on right carrier; one central braced mast and two yoke members'})
# GA cable route topology, flat on main roof except source vertical plantroom rise.
route=[(600,270),(600,300),(620,320),(685,320),(685,476),(558,476),(558,535),(386,535)]
for aa,bb in zip(route,route[1:]):
 a=xy(*aa);b=xy(*bb);beam((*a,roof+180),(*b,roof+180),300,80,'proposed_cable_tray')
for aa,bb in [((685,476),(716,532)),((558,476),(558,456))]:
 a=xy(*aa);b=xy(*bb);beam((*a,roof+180),(*b,roof+180),300,80,'proposed_cable_tray')
# Safety rails are separate from masonry parapet.
for k,(a,b) in enumerate(zip(outline,outline[1:]+outline[:1])):
 if np.linalg.norm(b-a)<2000:continue
 for t in np.linspace(.08,.92,max(2,int(np.linalg.norm(b-a)/1800))):
  q=a*(1-t)+b*t;beam((*q,roof+780),(*q,roof+1100),35,35,'roof_safety_rail')
 beam((*a,roof+1100),(*b,roof+1100),35,35,'roof_safety_rail')
# Schedule BOBs and GPS nodes, grouped independently for the editable review model.
for k,(px,py) in enumerate([(gx+300,gy+2800),(gx+gw-400,gy+2800)]):
 tube((px,py,deck),(px,py,deck+1500),38.05,'cabinet_BOB_support_'+str(k))
 for j in range(3 if k==0 else 6):
  w,d,h=(307,170,342) if k==0 else (220,440,180)
  box(px-w/2,py-d/2,deck+250+j*200,w,d,h,'cabinet_BOB_'+str(k)+'_'+str(j),'equipment')
for sec,az,c,_,_ in sectors:
 bearing=math.radians(az);r=np.array([math.cos(bearing),-math.sin(bearing)])
 for j,(w,d,h) in enumerate([(307,170,342),(200,200,140),(200,200,140)]):
  q=c+r*(j-1)*400;box(q[0]-w/2,q[1]-d/2,roof+800,w,d,h,sec+'_BOB_'+str(j),'equipment')
for j in range(2):
 q=xy(405+j*10,530);tube((*q,roof),(*q,roof+1700),25,'GPS_support_'+str(j));tube((*q,roof+1700),(*q,roof+1780),65,'GPS_node_'+str(j),'equipment')
# Roof access ladder from adjacent +24m level; GA locates this at the north return.
q=xy(608,253)
for dx in [-250,250]:tube((q[0]+dx,q[1]+100,24000),(q[0]+dx,q[1]+100,27100),28,'roof_access_ladder')
for zz in range(24200,26300,280):tube((q[0]-250,q[1]+100,zz),(q[0]+250,q[1]+100,zz),18,'roof_access_ladder')
# Walkway matting follows the route, offset inboard; 910 width from GA.
for aa,bb in zip(route,route[1:]):
 a=xy(*aa);b=xy(*bb);u=b-a;u/=np.linalg.norm(u);offset=np.array([-u[1],u[0]])*580
 beam((*(a+offset),roof+20),(*(b+offset),roof+20),910,25,'walkway_matting','walkway')
mesh={'vertices':V,'faces':F,'groups':G,'materials':M,'colors':C,'units':'mm','up_axis':'Z','origin':'Southwest GA roof reference projected to ground','coordinate_note':'Xeast/Ynorth; positive orientation; plan coordinates graphically fitted to written survey references'}
(O/'mesh.json').write_text(json.dumps(mesh,separators=(',',':')))
(O/'parameters.json').write_text(json.dumps({'XGA':XGA,'XM':XM,'YGA':YGA,'YM':YM,'GA_y_scale_for_unmeasured_intervals':54,'roof_level':roof,'plant_room_roof':27420,'parapet':780,'antenna_centre':30000,'sector_supports':sector_record,'ga_outline':outlineGA,'survey_constraints_mm':{'northwest_clear':4800,'core_clear':3500,'east_return_to_roof_edge':5500,'north_overhang':1700,'west_return':7400,'east_return':3000},'northeast_terrace':{'outer_GA_east':767.4,'north_GA':252.9,'south_GA':397,'roof_outline_unchanged':True,'extent_status':'Visual footprint fitted to engineer green markup, GoogleEarth view and GA lowerroof outline; not a new surveyed dimension'},'topfloor_visual_section':{'floor_level_proxy':TOP_BASE,'roof_soffit_proxy':ROOF_SOFFIT,'note':'Floor height, slab/beam depths and column sections are unmeasured visual envelopes; not fabrication dimensions'},'unmeasured_facade_geometry':'Photo interpreted; visual review geometry, not surveyed fabrication dimensions','equipment_geometry':'Review envelopes; verify antenna schedule dimensions before detailed fabrication'},indent=2)+'\n')
print('Mesh',len(V),'vertices',len(F),'faces',flush=True)
# Full-size editable CAD, grouped by building/equipment component. Cosmetic joints omitted.
import ezdxf
cad=ezdxf.new('R2000');cad.units=4;ms=cad.modelspace()
for g in sorted(set(G)):cad.layers.new(g,dxfattribs={'color':7})
for f,g,m in zip(F,G,M):
 if g.startswith('cosmetic'):continue
 pts=[V[i-1] for i in f];attrs={'layer':g,'true_color':ezdxf.colors.rgb2int(tuple(round(c*255) for c in C[m]))}
 if len(pts)<=4:ms.add_3dface(pts,dxfattribs=attrs)
 else:
  for j in range(1,len(pts)-1):ms.add_3dface([pts[0],pts[j],pts[j+1]],dxfattribs=attrs)
cad.saveas(D/'5166-building-model.dxf')
# STEP surfaces remain independently editable faces; no invented hidden solids.
import cadquery as cq
parts={}
for f,g in zip(F,G):
 if g.startswith('cosmetic'):continue
 pts=[cq.Vector(*V[i-1]) for i in f]
 try:s=cq.Face.makeFromWires(cq.Wire.makePolygon(pts,close=True));parts.setdefault(g,[]).append(s)
 except Exception:
  for j in range(1,len(pts)-1):parts.setdefault(g,[]).append(cq.Face.makeFromWires(cq.Wire.makePolygon([pts[0],pts[j],pts[j+1]],close=True)))
assy=cq.Assembly(name='5166_Tadworth_House_Review')
for g,fs in parts.items():assy.add(cq.Compound.makeCompound(fs),name=g)
assy.save(str(D/'5166-building-model.step'))
print('Editable STEP and3D DXF complete',flush=True)
