7068 — SOUTH WATER TOWER
Revision 1 | Jet Network Solutions | Drawn ST | Checked AF

7068-01: Roof plan and support arrangement, 1:100 at A3.
7068-02: South and east elevations, 1:150 at A3, and 3D view NTS.

The PDF contains two A3 landscape sheets. The DWG contains two named paper layouts and editable drawing views. Sheet blocks use A3 millimetres. The uninserted TOWER_SURFACE_MM block contains full-size millimetre surface geometry. The shaded 3D view is also supplied as a separate PNG.

OBJ and MTL exports will follow approval of the 3D model.
