7068 SOUTH WATER TOWER — APPROVED MODEL
Revision1 | Jet Network Solutions | ST / AF

Keep 7068-south-water-tower.obj and 7068-south-water-tower.mtl together. Import units METRES. Y is vertical; ground Y=0. X points east; negative Z points north.

Polygon surface geometry, with named parts and flat colour materials. No external image textures. Explicit face normals supplied. Select wireframe or feature-edge display in your software as required; importers may triangulate polygon surfaces.

Exported from the engineer-approved review model.
