HOWMIC COURT - 3280 FRAME REVISION - REVIEW DRAFT
16 November 2026. All dimensions in mm.

This package covers only the two lower braced frames shown in the user's
snippets (A-A and B-B). It is not a construction issue or structural approval.

REQUIREMENTS
Wall outside dimension 3800. Walls 230 each. Clear gap 3340.
Revised finished steel envelope 3280: 30 clearance each end.
The supplied fabrication rails are 3350, extending 5 beyond each wall-face
reference in plan. Their physical reduction is therefore 70, not 60.
The existing 50 mm outer edge to outer post-centre offsets are retained.
A-A chain: 50 + 1246 + 681 + 1253 + 50 = 3280.
B-B chain: 50 + 690 + 1805 + 685 + 50 = 3280.
Marked door dimensions are post-centre drawing references, not clear
face-to-face openings. With 100-wide posts the nominal clear widths are
581, 590 and 585 respectively; verify actual door requirements on site.
Frame heights 1200 and C5-C12 member lengths 998 are retained.

CONTENTS
HOWMIC-frame-revision-REVIEW.pdf: six review sheets, including plate holes.
HOWMIC-frames-3280-DRAFT.dxf: two 1:1 coordinated front elevations in mm.
draft-members/: 12 revised part profiles, comprising B11-B14, BR3-BR7,
p9-L (quantity 2), p9-R (quantity 2) and p11 (quantity 4).
unchanged-members/: C5-C12 and p10, copied byte-for-byte from the uploads.
member-schedule.csv: rail/brace cut lengths and quantities.
connection-checks.json and profile-checks.json: geometric check results.

ASSEMBLY
p9-L serves the 1246 side bay (left viewed as A-A), upper outer and lower
inner connections. p9-R serves the 1253 side bay, upper outer and lower
inner connections. The original shared p9 quantity 4 is replaced by 2+2.
p11 remains a single profile, quantity 4. p10 is unchanged, but rotates
with the revised diagonal. Do not scale or stretch whole parts: hole
sizes, section widths, end distances and pitches are preserved.
Plate outlines and fixed rail/post holes remain unchanged. Only brace
hole groups in p9/p11 move to suit the new brace angles.
The new single-door geometry follows the 681 requirement, correcting
the 675 shown in the old elevation. Bay widths follow the required
7 mm left/right asymmetry and the 3280 overall envelope.

CHECKS AND LIMITS
All revised DXFs were reopened and audited. Full frame envelopes are
3280 x 1200. Seventy mating hole centres agree within 0.010 mm, consistent
with input coordinates rounded to hundredths. Minimum plate material
between a hole edge and blank edge remains 16.205 for p9 and 16.000 for
p11. These are geometric comparisons, not strength or code checks.
The profiles retain computational precision; fabrication tolerances
must be agreed by the designer/fabricator.

Before manufacture, the responsible designer/fabricator must review
brace capacity, revised gussets/bolts, wall anchor reach and embedment,
packing across 30 mm gaps, site dimensions and actual door clearances.
Original Rev 0 DWGs/PDF are not amended or reissued. Grillage B4/B7 and
all other excluded components remain as supplied.
